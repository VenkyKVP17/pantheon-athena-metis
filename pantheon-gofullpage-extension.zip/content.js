/**
 * Pantheon GoFullPage Content Script
 * Handles DOM scrolling, dimension measurements, and scroll position restoration.
 */

(function () {
  let originalOverflowY = '';
  let originalScrollX = 0;
  let originalScrollY = 0;

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'getPageDimensions') {
      originalScrollX = window.scrollX;
      originalScrollY = window.scrollY;

      const body = document.body;
      if (body) {
        originalOverflowY = body.style.overflowY;
        body.style.overflowY = 'visible';
      }

      const viewportWidth = window.innerWidth;
      const viewportHeight = window.innerHeight;
      const fullWidth = Math.max(
        document.documentElement.clientWidth,
        body ? body.scrollWidth : 0,
        document.documentElement.scrollWidth,
        body ? body.offsetWidth : 0,
        document.documentElement.offsetWidth
      );
      const fullHeight = Math.max(
        document.documentElement.clientHeight,
        body ? body.scrollHeight : 0,
        document.documentElement.scrollHeight,
        body ? body.offsetHeight : 0,
        document.documentElement.offsetHeight
      );

      // Generate grid of scroll positions
      const positions = [];
      for (let y = 0; y < fullHeight; y += viewportHeight) {
        positions.push({ x: 0, y: y });
      }

      sendResponse({
        viewportWidth,
        viewportHeight,
        fullWidth,
        fullHeight,
        devicePixelRatio: window.devicePixelRatio || 1,
        positions,
        title: document.title || 'Screenshot',
        url: window.location.href
      });
      return true;
    }

    if (request.action === 'scrollToPosition') {
      window.scrollTo(request.position.x, request.position.y);
      // Short delay for layout reflow & sticky header adjustments
      setTimeout(() => {
        sendResponse({ done: true });
      }, 150);
      return true;
    }

    if (request.action === 'restoreScroll') {
      window.scrollTo(originalScrollX, originalScrollY);
      if (document.body) {
        document.body.style.overflowY = originalOverflowY;
      }
      sendResponse({ restored: true });
      return true;
    }
  });
})();
