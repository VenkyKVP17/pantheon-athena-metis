document.addEventListener('DOMContentLoaded', async () => {
  const btnCapture = document.getElementById('btnCapture');
  const inputWebhook = document.getElementById('inputWebhook');
  const progressBox = document.getElementById('progressBox');
  const progressFill = document.getElementById('progressFill');
  const statusText = document.getElementById('statusText');

  // Load saved Webhook URL
  const { webhookUrl = 'https://pantheon.katthan.in/api/gofullpage/webhook' } =
    await chrome.storage.sync.get('webhookUrl');
  inputWebhook.value = webhookUrl;

  // Auto-save Webhook URL on edit
  inputWebhook.addEventListener('input', () => {
    chrome.storage.sync.set({ webhookUrl: inputWebhook.value.trim() });
  });

  // Listen for progress messages from background
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === 'captureProgress') {
      const { step, total, status, complete, webhookSuccess, webhookMessage } = message.data;

      progressBox.style.display = 'flex';
      statusText.innerText = status;

      if (step && total) {
        const pct = Math.round((step / total) * 100);
        progressFill.style.width = pct + '%';
      }

      if (complete) {
        progressFill.style.width = '100%';
        btnCapture.disabled = false;

        if (webhookSuccess) {
          statusText.style.color = '#34d399';
          statusText.innerText = '✅ Capture Complete & Webhook Delivered!';
        } else if (webhookMessage) {
          statusText.style.color = '#fbbf24';
          statusText.innerText = '⚠️ ' + webhookMessage;
        }
      }
    }
  });

  // Trigger Capture
  btnCapture.addEventListener('click', async () => {
    btnCapture.disabled = true;
    progressBox.style.display = 'flex';
    progressFill.style.width = '5%';
    statusText.style.color = '#00f2fe';
    statusText.innerText = 'Starting GoFullPage capture...';

    // Get active tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) {
      statusText.innerText = 'Error: No active tab found.';
      btnCapture.disabled = false;
      return;
    }

    chrome.runtime.sendMessage({ action: 'startFullPageCapture', tabId: tab.id }, (response) => {
      if (chrome.runtime.lastError) {
        statusText.innerText = 'Error: ' + chrome.runtime.lastError.message;
        btnCapture.disabled = false;
      }
    });
  });
});
