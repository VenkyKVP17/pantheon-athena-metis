/**
 * Pantheon GoFullPage Background Service Worker (Manifest V3)
 * Coordinates scrolling, tab captures, canvas stitching, and Webhook POST dispatch.
 */

chrome.commands.onCommand.addListener((command) => {
  if (command === 'capture_full_page') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        executeFullPageCapture(tabs[0].id);
      }
    });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'startFullPageCapture') {
    executeFullPageCapture(message.tabId)
      .then((result) => sendResponse({ status: 'success', data: result }))
      .catch((err) => sendResponse({ status: 'error', message: err.message }));
    return true; // Keep channel open for async response
  }
});

async function executeFullPageCapture(tabId) {
  // Get stored webhook URL or default
  const { webhookUrl = 'https://pantheon.katthan.in/api/gofullpage/webhook' } =
    await chrome.storage.sync.get('webhookUrl');

  // Inject content script if needed
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ['content.js']
  });

  // Get page measurements & positions
  const dims = await chrome.tabs.sendMessage(tabId, { action: 'getPageDimensions' });
  const { viewportWidth, viewportHeight, fullWidth, fullHeight, devicePixelRatio, positions, title, url } = dims;

  const capturedChunks = [];

  for (let i = 0; i < positions.length; i++) {
    const pos = positions[i];
    
    // Broadcast progress
    notifyProgress({ step: i + 1, total: positions.length, status: `Capturing section ${i + 1}/${positions.length}...` });

    // Scroll to section
    await chrome.tabs.sendMessage(tabId, { action: 'scrollToPosition', position: pos });

    // Capture visible viewport
    const dataUrl = await chrome.tabs.captureVisibleTab(null, { format: 'png' });
    capturedChunks.push({ pos, dataUrl });
  }

  // Restore scroll
  await chrome.tabs.sendMessage(tabId, { action: 'restoreScroll' });

  notifyProgress({ status: 'Stitching full-page canvas...' });

  // Stitch canvas using OffscreenCanvas or DataURL Blob assembly
  const finalCanvasWidth = Math.round(viewportWidth * devicePixelRatio);
  const finalCanvasHeight = Math.round(fullHeight * devicePixelRatio);

  const offscreen = new OffscreenCanvas(finalCanvasWidth, finalCanvasHeight);
  const ctx = offscreen.getContext('2d');

  for (let i = 0; i < capturedChunks.length; i++) {
    const chunk = capturedChunks[i];
    const response = await fetch(chunk.dataUrl);
    const blob = await response.blob();
    const imageBitmap = await createImageBitmap(blob);

    const drawY = Math.round(chunk.pos.y * devicePixelRatio);
    ctx.drawImage(imageBitmap, 0, drawY);
  }

  const resultBlob = await offscreen.convertToBlob({ type: 'image/png' });
  
  notifyProgress({ status: 'Sending screenshot to Webhook...' });

  const nowMs = Date.now();
  const istDateStr = new Date().toLocaleString('sv-SE', { timeZone: 'Asia/Kolkata' }).replace(' ', 'T') + '+05:30';

  // Prepare FormData for Webhook POST
  const formData = new FormData();
  formData.append('screenshot', resultBlob, `athena_dropzone_${nowMs}.png`);
  formData.append('title', title);
  formData.append('url', url);
  formData.append('timestamp', new Date().toISOString());
  formData.append('timestamp_ms', nowMs.toString());
  formData.append('timestamp_ist', istDateStr);

  let webhookSuccess = false;
  let webhookMessage = '';

  if (webhookUrl) {
    try {
      const resp = await fetch(webhookUrl, {
        method: 'POST',
        body: formData
      });
      if (resp.ok) {
        webhookSuccess = true;
        webhookMessage = 'Webhook delivered successfully!';
      } else {
        webhookMessage = `Webhook error: ${resp.status} ${resp.statusText}`;
      }
    } catch (e) {
      webhookMessage = `Webhook fetch failed: ${e.message}`;
    }
  }

  notifyProgress({ status: 'Done!', complete: true, webhookSuccess, webhookMessage });

  return {
    title,
    url,
    fullWidth,
    fullHeight,
    webhookSuccess,
    webhookMessage
  };
}

function notifyProgress(data) {
  chrome.runtime.sendMessage({ action: 'captureProgress', data }).catch(() => {});
}
