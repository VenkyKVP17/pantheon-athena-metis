# 📸 Pantheon GoFullPage Webhook Chrome Extension

> **Manifest V3 Full-Page Screenshot Capturer & Webhook Dispatcher** powered by the **GoFullPage** open-source scrolling engine.

---

## 🌟 Key Features

1. **GoFullPage Engine**:
   - Accurately measures page height & width.
   - Handles `overflow-y: visible` adjustments for tricky layouts.
   - Smoothly scrolls step-by-step with layout reflow delays.
2. **Offscreen Canvas Stitching (Manifest V3)**:
   - Stitches all captured viewport PNG chunks into a single, high-resolution full-page screenshot using `OffscreenCanvas`.
3. **Automatic Webhook Push**:
   - Posts FormData (`screenshot`, `title`, `url`, `timestamp`) directly to your server webhook endpoint.
   - Default Endpoint: `https://pantheon.katthan.in/api/gofullpage/webhook`.
4. **Keyboard Shortcut**:
   - `Alt + Shift + S` (or `Cmd + Shift + S` on Mac) triggers instant full-page capture and webhook upload.
5. **Configurable Popup UI**:
   - Built with Pantheon dark glassmorphism theme, live progress bar, and custom Webhook URL editor.

---

## 📁 Extension Architecture

```
pantheon-gofullpage-extension/
├── manifest.json       # Chrome Manifest V3 configuration & permissions
├── popup.html          # Dark glassmorphism popup UI
├── popup.js            # UI handlers, progress listener & settings auto-save
├── content.js          # Injected DOM scroll engine & viewport position calculator
└── background.js       # Service worker: coordinate captures, canvas stitcher & fetch POST
```

---

## 🚀 How to Install in Google Chrome

1. Open **Google Chrome** and navigate to `chrome://extensions`.
2. Enable **Developer mode** toggle in the top-right corner.
3. Click **Load unpacked** button.
4. Select the `pantheon-gofullpage-extension` folder.
5. Click the extension icon or press **`Alt + Shift + P`** on any web page to capture and send screenshots directly to your Pantheon server!

---

## 🛰️ Server Webhook Endpoint

Captured screenshots are received by `POST /api/gofullpage/webhook` and automatically saved on the server at:
`/home/ubuntu/vp/06-Agent_Outputs/GoFullPage/fullpage_<title>_<timestamp>.png`

---
*Governed by: ZEUS ⚡ & NYX 🌙*
